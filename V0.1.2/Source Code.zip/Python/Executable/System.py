# Myth Desktop AI Assistant System
# Just Say "Myth"

# dependencies
import Commands

import random
from os import path

# import data
speakerName = 'Attachment Aditya'

random_name = ['Pickly Boi', 'Bing Master', 'Pine-Apple Eater', 'Richy Bills']

if path.exists("data/speaker.txt"):
	try:
		with open('data/speaker.txt') as f:
			speakerName = f.read()
			f.close()
	except:
		pass
else:
	try:
		speakerName = random.choice(random_name)
	except:
		pass

myName = 'Myth'

if path.exists("data/myName.txt"):
	try:
		with open('data/myName.txt') as f:
			myName = f.read()
			f.close()
	except:
		pass
else:
	try:
		myName = 'Myth'
	except:
		pass

# basic functions


def say(text):
	print("" + text)


def stop_busting():
	say('Alright, I Will Sleep Till You Give Next Myth')
	Commands.stop()
