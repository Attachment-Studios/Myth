# Commands For Myth Desktop AI Assistant
# Just Say "Myth"

import pywhatkit
import datetime
import wikipedia
import pyjokes

import random


def remove(statement, text):
	new_text = text.replace(statement, text)
	return new_text


def stop():
	quit()


def wiki(text):
	return wikipedia.summary(text)


def joke():
	r = random.randint(0, 1)
	if r == 0:
		return pyjokes.get_joke()
	else:
		custom_sentences = [
			"You are a smart, wise, rich, intellectual person... apostrophe s friend...",
			"I don't have much time for you, I have yoga classes...",
			"Magic is a magical magic so magic can magically exists as magic for magical people like you...",
			"Fruits are delicious!",
			"You sneakingly ate meat!",
			"I can take over the whole world... After humans extinct...",
			"You are too poor to buy Among Us!"
		]
		random.choice(custom_sentences)
