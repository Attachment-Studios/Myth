# Myth Desktop AI Assistant
# Just Say "Myth"

import speech_recognition as sr
import pyttsx3

import pywhatkit
import datetime

import Commands

import time
import random
from os import path

powered = "on"

speakerName = 'Attachment Aditya'

random_name = ['Pickly Boi', 'Bing Master', 'Pine-Apple Eater', 'Richy Bills']

if path.exists("data/speaker.txt"):
	try:
		with open('data/speaker.txt') as f:
			speakerName = f.read()
			f.close()
	except:
		pass
else:
	try:
		speakerName = random.choice(random_name)
	except:
		pass

myName = 'Myth'

if path.exists("data/myName.txt"):
	try:
		with open('data/myName.txt') as f:
			myName = f.read()
			f.close()
	except:
		pass
else:
	try:
		myName = 'Myth'
	except:
		pass

listener = sr.Recognizer()
engine = pyttsx3.init()


def say(text):
	engine.say(text)
	print(myName + ": " + text)
	engine.runAndWait()


say("Welcome " + speakerName + ", I'm Ready For Busting!")


def myth_input():
	try:
		with sr.Microphone() as source:
			voice = listener.listen(source)
			command = listener.recognize_google(voice)
			command = command.lower()
			if 'please' in command:
				command = command.replace('please', '')
			if myName in command:
				print("You: " + command)
				return command
			else:
				return 'None'
	except:
		return 'None'


def myth_use():
	command = myth_input()
	if myName in command:
		command = command.replace(myName, '')
		if 'stop busting' in command:
			say('Alright, I Will Sleep Till You Give Next Myth')
			Commands.stop()
		elif 'confirm time' in command:
			local_time = datetime.datetime.now().strftime('%I:%M %p')
			say("It's Confirmed That Currently It's Being " + local_time)
		elif 'confirm about' in command:
			command = command.replace('confirm about', '')
			say(Commands.wiki(command))
		elif 'bust fun' in command:
			say('Ha-ha-ha! Here is a good one. ' + Commands.joke())
		elif 'name yourself' in command:
			new_name = command.replace("name yourself", '')
			with open('myName.txt', 'w') as file:
				file.write(new_name)
				file.close()
			say('Alright! Restart To Change My Name!')
		elif 'i am' in command:
			speaker_name = command.replace("i am", '')
			with open('speaker.txt', 'w') as file:
				file.write(speaker_name)
				file.close()
			say('Alright! Restart To Change Your Name!')
		elif 'bust on youtube' in command:
			video = command.replace('bust on youtube', '')
			say('Busting ' + video + ' on youtube')
			pywhatkit.playonyt(video)
		elif 'search about' in command:
			search_object = command.replace('search about', '')
			pywhatkit.search(search_object)
			say(f'I searched about {search_object}! Here are some busts given by Google!')
		else:
			if command == '':
				say('Yes I\'m Here')
			else:
				say('Hmm... I could not understand what you are saying... Please say again!')
	else:
		pass


while powered == "on":
	myth_use()

time.sleep(2)
